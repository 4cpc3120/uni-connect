import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Settings, Edit, ChevronRight, BookmarkCheck, TrendingUp } from 'lucide-react';
import { getCurrentUser, getPosts, getCurrentUserId } from '../lib/store';

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    lastName: '山田',
    firstName: '太郎',
    faculty: '経営学部',
    year: '3年',
  });
  const [bio, setBio] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  const [stats, setStats] = useState({ participating: 0, hosting: 0 });

  useEffect(() => {
    const u = getCurrentUser();
    if (u) {
      setUser({ lastName: u.lastName, firstName: u.firstName, faculty: u.faculty, year: u.year });
      setBio(u.bio);
      setInterests(u.interests);
    } else {
      const storedBio = localStorage.getItem('user_bio');
      const storedInterests = localStorage.getItem('user_interests');
      if (storedBio) setBio(storedBio);
      if (storedInterests) setInterests(JSON.parse(storedInterests));
    }

    const userId = getCurrentUserId();
    const all = getPosts();
    setStats({
      participating: all.filter((p) => p.participants.includes(userId) && p.hostId !== userId).length,
      hosting: all.filter((p) => p.hostId === userId).length,
    });
  }, []);

  const menuItems = [
    { label: '参加している募集', icon: BookmarkCheck, path: '/profile/participating', count: stats.participating },
    { label: '自分の募集', icon: TrendingUp, path: '/profile/my-posts', count: stats.hosting },
  ];

  const [showSettings, setShowSettings] = useState(false);

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm flex items-center justify-between">
        <h1 className="text-xl">マイページ</h1>
        <button className="p-2" onClick={() => setShowSettings(!showSettings)}>
          <Settings size={24} className="text-gray-600" />
        </button>
      </header>

      {showSettings && (
        <div className="bg-white border-b border-gray-100 px-5 py-3">
          <button
            onClick={() => navigate('/terms')}
            className="flex items-center justify-between w-full py-2 text-sm text-gray-600"
          >
            <span>利用規約を確認する</span>
            <ChevronRight size={16} className="text-gray-400" />
          </button>
          <button
            onClick={() => {
              if (confirm('ログアウトしますか？')) {
                localStorage.removeItem('onboarding_complete');
                window.location.reload();
              }
            }}
            className="flex items-center w-full py-2 text-sm text-red-500"
          >
            ログアウト
          </button>
        </div>
      )}

      <div className="bg-white px-5 py-8 mb-2">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white flex-shrink-0">
            <span className="text-2xl">{(user.lastName || 'U').charAt(0)}</span>
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="mb-1">{user.lastName} {user.firstName}</h2>
            <p className="text-sm text-gray-500">{user.faculty} {user.year}</p>
            <button
              onClick={() => navigate('/profile/edit')}
              className="mt-2 px-4 py-1.5 border border-gray-300 rounded-lg text-sm flex items-center gap-2"
            >
              <Edit size={16} />
              プロフィール編集
            </button>
          </div>
        </div>

        {bio && (
          <div className="bg-gray-50 rounded-xl p-4 mb-6">
            <p className="text-sm text-gray-600 leading-relaxed">{bio}</p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/profile/participating')}
            className="text-center py-4 bg-blue-50 rounded-xl"
          >
            <p className="text-2xl font-semibold text-blue-700">{stats.participating}</p>
            <p className="text-xs text-gray-500 mt-1">参加中</p>
          </button>
          <button
            onClick={() => navigate('/profile/my-posts')}
            className="text-center py-4 bg-blue-50 rounded-xl"
          >
            <p className="text-2xl font-semibold text-blue-700">{stats.hosting}</p>
            <p className="text-xs text-gray-500 mt-1">募集中</p>
          </button>
        </div>
      </div>

      <div className="bg-white mb-2">
        <div className="px-5 py-3 border-b border-gray-100">
          <h3 className="text-sm text-gray-400">アクティビティ</h3>
        </div>
        {menuItems.map((item, i) => {
          const Icon = item.icon;
          return (
            <button
              key={i}
              onClick={() => navigate(item.path)}
              className="w-full px-5 py-4 flex items-center justify-between border-b border-gray-100 last:border-b-0 hover:bg-gray-50 active:bg-gray-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Icon size={20} className="text-gray-400" />
                <span>{item.label}</span>
              </div>
              <div className="flex items-center gap-2">
                {item.count > 0 && (
                  <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                    {item.count}
                  </span>
                )}
                <ChevronRight size={20} className="text-gray-400" />
              </div>
            </button>
          );
        })}
      </div>

      {interests.length > 0 && (
        <div className="bg-white">
          <div className="px-5 py-3 border-b border-gray-100">
            <h3 className="text-sm text-gray-400">興味のあるカテゴリ</h3>
          </div>
          <div className="px-5 py-4">
            <div className="flex flex-wrap gap-2">
              {interests.map((tag, i) => (
                <span key={i} className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-full text-sm">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
