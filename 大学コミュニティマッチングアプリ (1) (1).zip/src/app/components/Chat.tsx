import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { MessageCircle } from 'lucide-react';
import { getPosts, getMessages, getCurrentUserId, formatTimeAgo, type Post } from '../lib/store';

export default function Chat() {
  const navigate = useNavigate();
  const [chatList, setChatList] = useState<
    { post: Post; lastMessage: string; lastTime: number | null }[]
  >([]);

  useEffect(() => {
    const userId = getCurrentUserId();
    const posts = getPosts().filter(
      (p) => p.hostId === userId || p.participants.includes(userId)
    );
    const list = posts.map((post) => {
      const msgs = getMessages(post.id);
      const last = msgs[msgs.length - 1];
      return {
        post,
        lastMessage: last?.content ?? 'チャットを開いて交流しましょう',
        lastTime: last?.createdAt ?? null,
      };
    });
    // Sort by most recent message
    list.sort((a, b) => (b.lastTime ?? b.post.createdAt) - (a.lastTime ?? a.post.createdAt));
    setChatList(list);
  }, []);

  const CATEGORY_AVATAR_COLORS: Record<string, string> = {
    '就活': 'bg-blue-100 text-blue-600',
    '勉強': 'bg-green-100 text-green-600',
    'サークル': 'bg-purple-100 text-purple-600',
    'その他': 'bg-orange-100 text-orange-600',
  };

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm sticky top-0 z-10">
        <h1 className="text-xl">チャット</h1>
      </header>

      {chatList.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 px-5 text-center">
          <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mb-4">
            <MessageCircle size={32} className="text-blue-400" />
          </div>
          <h3 className="mb-2">チャットがありません</h3>
          <p className="text-sm text-gray-500 mb-6">
            募集に参加するとチャットが表示されます
          </p>
          <button
            onClick={() => navigate('/posts')}
            className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm"
          >
            募集を探す
          </button>
        </div>
      ) : (
        <div className="divide-y divide-gray-100 bg-white mt-2 rounded-t-xl">
          {chatList.map(({ post, lastMessage, lastTime }) => (
            <button
              key={post.id}
              onClick={() => navigate(`/chat/${post.id}`)}
              className="w-full bg-white px-5 py-4 hover:bg-gray-50 active:bg-gray-100 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 font-medium ${
                    CATEGORY_AVATAR_COLORS[post.category] ?? 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {post.title.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className="truncate text-base">{post.title}</h3>
                    <span className="text-xs text-gray-400 flex-shrink-0 ml-2">
                      {lastTime ? formatTimeAgo(lastTime) : formatTimeAgo(post.createdAt)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">{lastMessage}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
