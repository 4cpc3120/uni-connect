import { useState } from 'react';
import WelcomeScreen from './onboarding/WelcomeScreen';
import TermsAgreement from './onboarding/TermsAgreement';
import EmailVerification from './onboarding/EmailVerification';
import PersonalInfo from './onboarding/PersonalInfo';
import InterestSelection from './onboarding/InterestSelection';
import TermsOfService from './TermsOfService';
import { getCurrentUserId } from '../lib/store';

interface OnboardingProps {
  onComplete: () => void;
}

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [showFullTerms, setShowFullTerms] = useState(false);
  const [email, setEmail] = useState('');
  const [personalInfo, setPersonalInfo] = useState({
    lastName: '',
    firstName: '',
    faculty: '',
    department: '',
    year: '',
    studentId: '',
  });

  if (showFullTerms) {
    return (
      <div className="h-screen w-full max-w-md mx-auto bg-white overflow-y-auto">
        <TermsOfService onBack={() => setShowFullTerms(false)} />
      </div>
    );
  }

  const handleEmailVerified = (verifiedEmail: string) => {
    setEmail(verifiedEmail);
    setStep(3);
  };

  const handlePersonalInfoComplete = (info: typeof personalInfo) => {
    setPersonalInfo(info);
    setStep(4);
  };

  const handleInterestsComplete = (interests: string[]) => {
    getCurrentUserId(); // ensure user ID is generated
    localStorage.setItem('user_email', email);
    localStorage.setItem('user_info', JSON.stringify(personalInfo));
    localStorage.setItem('user_interests', JSON.stringify(interests));
    onComplete();
  };

  return (
    <div className="h-screen w-full max-w-md mx-auto bg-white">
      {step === 0 && <WelcomeScreen onNext={() => setStep(1)} />}
      {step === 1 && (
        <TermsAgreement
          onAgree={() => setStep(2)}
          onViewTerms={() => setShowFullTerms(true)}
        />
      )}
      {step === 2 && <EmailVerification onVerified={handleEmailVerified} />}
      {step === 3 && <PersonalInfo onComplete={handlePersonalInfoComplete} />}
      {step === 4 && <InterestSelection onComplete={handleInterestsComplete} />}
    </div>
  );
}
