import { useLocation, useNavigate } from 'react-router';
import { Home, FileText, MessageCircle, User } from 'lucide-react';

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { path: '/home', icon: Home, label: 'ホーム' },
    { path: '/posts', icon: FileText, label: '募集' },
    { path: '/chat', icon: MessageCircle, label: 'チャット' },
    { path: '/profile', icon: User, label: 'マイページ' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200 shadow-lg">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center justify-center flex-1 h-full"
            >
              <Icon
                size={24}
                className={isActive ? 'text-blue-600' : 'text-gray-400'}
              />
              <span
                className={`text-xs mt-1 ${
                  isActive ? 'text-blue-600' : 'text-gray-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
