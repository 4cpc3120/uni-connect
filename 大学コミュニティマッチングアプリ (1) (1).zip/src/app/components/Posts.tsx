import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { Search } from 'lucide-react';
import { getPosts, formatTimeAgo, type Post } from '../lib/store';

const TABS = [
  { id: 'all', label: 'すべて' },
  { id: '就活', label: '就活' },
  { id: '勉強', label: '勉強' },
  { id: 'サークル', label: 'サークル' },
  { id: 'その他', label: 'その他' },
];

const CATEGORY_COLORS: Record<string, string> = {
  '就活': 'bg-blue-50 text-blue-600',
  '勉強': 'bg-green-50 text-green-600',
  'サークル': 'bg-purple-50 text-purple-600',
  'その他': 'bg-orange-50 text-orange-600',
};

export default function Posts() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('all');
  const [query, setQuery] = useState('');
  const [allPosts, setAllPosts] = useState<Post[]>([]);

  useEffect(() => {
    setAllPosts(getPosts());
  }, []);

  const filtered = useMemo(() => {
    let list = allPosts;
    if (activeTab !== 'all') list = list.filter((p) => p.category === activeTab);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)) ||
          p.hostFaculty.toLowerCase().includes(q)
      );
    }
    return list;
  }, [allPosts, activeTab, query]);

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm sticky top-0 z-10">
        <h1 className="text-xl mb-3">募集一覧</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="募集を検索"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>
      </header>

      <div className="bg-white border-b border-gray-200 sticky top-[108px] z-10">
        <div className="flex overflow-x-auto scrollbar-hide px-5 py-3 gap-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 py-4 space-y-3">
        {filtered.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-400 text-sm">
              {query ? `"${query}" に一致する募集はありません` : '募集がありません'}
            </p>
          </div>
        )}

        {filtered.map((post) => (
          <button
            key={post.id}
            onClick={() => navigate(`/posts/${post.id}`)}
            className="w-full bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-left active:scale-[0.99] transition-transform"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-medium">
                {post.hostName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm text-gray-600 truncate">
                    {post.hostFaculty} {post.hostYear}
                  </span>
                  <span className="text-xs text-gray-400 ml-auto flex-shrink-0">
                    {formatTimeAgo(post.createdAt)}
                  </span>
                </div>
                <h3 className="mb-1.5 leading-snug">{post.title}</h3>
                <p className="text-sm text-gray-500 mb-3 line-clamp-2">{post.description}</p>

                {post.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {post.tags.map((tag, i) => (
                      <span key={i} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <span className={`text-xs px-3 py-1 rounded-full ${CATEGORY_COLORS[post.category]}`}>
                    {post.category}
                  </span>
                  <span className="text-xs text-gray-400">
                    {post.participants.length + 1}/{post.maxParticipants}名参加中
                  </span>
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
