import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Users, MessageCircle } from 'lucide-react';
import { getPosts, getCurrentUserId, formatTimeAgo, type Post } from '../lib/store';

const CATEGORY_COLORS: Record<string, string> = {
  '就活': 'bg-blue-100 text-blue-600',
  '勉強': 'bg-green-100 text-green-600',
  'サークル': 'bg-purple-100 text-purple-600',
  'その他': 'bg-orange-100 text-orange-600',
};

export default function ParticipatingPosts() {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    const userId = getCurrentUserId();
    const list = getPosts().filter(
      (p) => p.participants.includes(userId) && p.hostId !== userId
    );
    setPosts(list);
  }, []);

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-1">
          <button onClick={() => navigate(-1)}>
            <ChevronLeft size={24} className="text-gray-600" />
          </button>
          <h1 className="text-xl">参加している募集</h1>
        </div>
        <p className="text-sm text-gray-500 ml-9">{posts.length}件の募集に参加中</p>
      </header>

      {posts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 px-5 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <Users size={32} className="text-gray-400" />
          </div>
          <h3 className="mb-2">参加している募集はありません</h3>
          <p className="text-sm text-gray-500 mb-6">
            募集一覧から気になる募集に参加してみましょう
          </p>
          <button
            onClick={() => navigate('/posts')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg"
          >
            募集を探す
          </button>
        </div>
      ) : (
        <div className="px-5 py-4 space-y-3">
          {posts.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
            >
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0 font-medium">
                  {post.hostName.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-500 mb-1">
                    {post.hostFaculty} {post.hostYear}
                  </p>
                  <h3 className="mb-2 leading-snug">{post.title}</h3>
                  <p className="text-sm text-gray-500 mb-3 line-clamp-2">{post.description}</p>

                  {post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {post.tags.map((tag, i) => (
                        <span key={i} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className={`text-xs px-3 py-1 rounded-full ${CATEGORY_COLORS[post.category]}`}>
                      {post.category}
                    </span>
                    <div className="flex items-center gap-1 text-xs text-gray-400">
                      <Users size={13} />
                      <span>{post.participants.length + 1}/{post.maxParticipants}名</span>
                    </div>
                  </div>

                  <p className="text-xs text-gray-400 mt-2">
                    投稿 {formatTimeAgo(post.createdAt)}
                  </p>
                </div>
              </div>
              <button
                onClick={() => navigate(`/chat/${post.id}`)}
                className="w-full py-2.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors flex items-center justify-center gap-2 text-sm"
              >
                <MessageCircle size={16} />
                チャットを開く
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
