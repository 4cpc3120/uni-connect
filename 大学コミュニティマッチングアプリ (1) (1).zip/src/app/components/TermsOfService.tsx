import { ChevronLeft } from 'lucide-react';

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="font-semibold text-gray-900 mb-2">{title}</h2>
      <div className="text-gray-600 space-y-2">{children}</div>
    </div>
  );
}

interface Props {
  onBack?: () => void;
}

export default function TermsOfService({ onBack }: Props) {
  const handleBack = onBack ?? (() => window.history.back());

  return (
    <div className="min-h-full bg-white">
      <header className="bg-white px-5 py-4 border-b border-gray-100 sticky top-0 z-10 flex items-center gap-3">
        <button onClick={handleBack}>
          <ChevronLeft size={24} className="text-gray-600" />
        </button>
        <h1 className="text-xl">利用規約</h1>
      </header>

      <div className="px-5 py-6 space-y-6 text-sm leading-relaxed">
        <div>
          <p className="text-gray-400 text-xs mb-3">最終更新日：2025年4月1日</p>
          <p className="text-gray-600">
            本利用規約（以下「本規約」）は、UniConnect（以下「本サービス」）の利用条件を定めるものです。
            ユーザーは本規約に同意した上で本サービスをご利用ください。
          </p>
        </div>

        <Section title="第1条（目的）">
          <p>
            本サービスは、東海大学の在学生同士が学部・学年を超えて交流し、就活仲間・勉強仲間・サークルメンバー等を見つけることを目的としたコミュニティ・マッチングサービスです。恋愛・異性交際を目的としたサービスではありません。
          </p>
        </Section>

        <Section title="第2条（利用資格）">
          <p>
            本サービスの利用は、東海大学が発行するメールアドレス（@tokai.ac.jp）を保有する在学生に限られます。
            卒業・退学等により在学生でなくなった場合は、直ちに利用を停止し、アカウント削除をお申し出ください。
          </p>
        </Section>

        <Section title="第3条（禁止事項）">
          <p>ユーザーは以下の行為を行ってはなりません。</p>
          <ul className="list-disc pl-5 space-y-1 mt-2">
            <li>他のユーザーへの嫌がらせ・誹謗中傷・脅迫行為</li>
            <li>虚偽の情報による登録・投稿・プロフィール作成</li>
            <li>商業目的での勧誘・営業・広告活動</li>
            <li>マルチ商法・ネットワークビジネスへの勧誘</li>
            <li>異性との交際・恋愛を主目的とした利用</li>
            <li>反社会的勢力に関係する活動への関与・勧誘</li>
            <li>他のユーザーの個人情報を無断で収集・漏洩する行為</li>
            <li>本サービスの運営を妨げるまたはサーバーに過大な負荷を与える行為</li>
            <li>他のユーザーや第三者の著作権・知的財産権を侵害する行為</li>
            <li>その他法令または本規約に違反する行為</li>
          </ul>
        </Section>

        <Section title="第4条（個人情報の取扱い）">
          <p>本サービスは、収集した個人情報を以下の目的のみに使用します。</p>
          <ul className="list-disc pl-5 space-y-1 mt-2">
            <li>本人確認・在学確認</li>
            <li>マッチング機能の提供</li>
            <li>サービス改善・統計分析（個人を特定しない形で実施）</li>
            <li>重要なお知らせの送信</li>
          </ul>
          <p className="mt-2">
            収集した個人情報は適切に管理し、法令に基づく場合を除き第三者への提供は行いません。
          </p>
        </Section>

        <Section title="第5条（投稿コンテンツ）">
          <p>
            ユーザーが投稿したコンテンツ（テキスト等）の著作権はユーザーに帰属しますが、
            本サービスの運営・改善・宣伝目的での使用を無償で許諾するものとします。
          </p>
          <p>
            不適切な投稿は運営が事前通知なく削除することがあります。
          </p>
        </Section>

        <Section title="第6条（免責事項）">
          <ul className="list-disc pl-5 space-y-1">
            <li>運営はユーザー間のトラブルについて一切の責任を負いません</li>
            <li>本サービスの中断・停止・廃止による損害について責任を負いません</li>
            <li>ユーザーが取得した情報の正確性・完全性について保証しません</li>
            <li>本サービスを通じて知り合った相手との対面での交流において発生した問題について責任を負いません</li>
          </ul>
        </Section>

        <Section title="第7条（利用停止・アカウント削除）">
          <p>
            運営は、ユーザーが本規約に違反した場合、事前通知なく当該ユーザーのアカウントを停止または削除することができます。
            また、アカウント削除を希望する場合は、お問い合わせフォームよりご連絡ください。
          </p>
        </Section>

        <Section title="第8条（規約の変更）">
          <p>
            運営は必要に応じて本規約を変更することができます。
            変更後の規約は本サービス上に掲示した時点で効力を生じます。
            重要な変更の場合は登録メールアドレスへの通知を行います。
          </p>
        </Section>

        <Section title="第9条（準拠法・管轄）">
          <p>
            本規約は日本法に準拠し、本サービスに関する紛争については
            東京地方裁判所を第一審の専属的合意管轄裁判所とします。
          </p>
        </Section>

        <div className="border-t border-gray-100 pt-5 space-y-1">
          <p className="text-gray-500">UniConnect 運営事務局</p>
          <p className="text-gray-500">東海大学内コミュニティサービス</p>
          <p className="text-gray-400 text-xs mt-2">
            お問い合わせ：サービス内のお問い合わせフォームよりご連絡ください
          </p>
        </div>
      </div>
    </div>
  );
}
