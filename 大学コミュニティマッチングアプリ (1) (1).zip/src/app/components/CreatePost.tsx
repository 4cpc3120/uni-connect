import { useState } from 'react';
import { useNavigate } from 'react-router';
import { X, Users } from 'lucide-react';
import { createPost, type Category } from '../lib/store';

const CATEGORIES: { id: Category; label: string; color: string }[] = [
  { id: '就活', label: '就活', color: 'bg-blue-100 text-blue-600 border-blue-400' },
  { id: '勉強', label: '勉強', color: 'bg-green-100 text-green-600 border-green-400' },
  { id: 'サークル', label: 'サークル', color: 'bg-purple-100 text-purple-600 border-purple-400' },
  { id: 'その他', label: 'その他', color: 'bg-orange-100 text-orange-600 border-orange-400' },
];

export default function CreatePost() {
  const navigate = useNavigate();
  const [category, setCategory] = useState<Category | ''>('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [maxParticipants, setMaxParticipants] = useState('5');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const addTag = () => {
    const t = tagInput.trim();
    if (t && tags.length < 5 && !tags.includes(t)) {
      setTags([...tags, t]);
      setTagInput('');
    }
  };

  const handleSubmit = () => {
    if (!title || !description || !category) return;
    setSubmitting(true);
    createPost({
      title,
      description,
      category: category as Category,
      tags,
      maxParticipants: Math.min(50, Math.max(2, parseInt(maxParticipants) || 5)),
    });
    navigate('/posts', { replace: true });
  };

  const canSubmit = title.trim() && description.trim() && category;

  return (
    <div className="min-h-full bg-white">
      <header className="px-5 py-4 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white z-10">
        <button onClick={() => navigate(-1)}>
          <X size={24} className="text-gray-600" />
        </button>
        <h1 className="text-xl">新規募集</h1>
        <button
          onClick={handleSubmit}
          disabled={!canSubmit || submitting}
          className={`px-4 py-2 rounded-lg transition-colors ${
            canSubmit && !submitting
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          }`}
        >
          投稿
        </button>
      </header>

      <div className="px-5 py-6 space-y-6">
        <div>
          <label className="block mb-3 text-sm text-gray-600">カテゴリ *</label>
          <div className="grid grid-cols-2 gap-3">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`px-4 py-3 rounded-xl border-2 transition-all text-sm font-medium ${
                  category === cat.id
                    ? cat.color
                    : 'bg-white text-gray-600 border-gray-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block mb-3 text-sm text-gray-600">タイトル *</label>
          <input
            type="text"
            placeholder="例：春休みGD練習会メンバー募集！"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
            maxLength={50}
          />
          <p className="text-xs text-gray-400 mt-2 text-right">{title.length}/50</p>
        </div>

        <div>
          <label className="block mb-3 text-sm text-gray-600">詳細 *</label>
          <textarea
            placeholder="募集内容の詳細を入力してください&#10;（活動頻度、場所、目標など）"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors resize-none"
            rows={6}
            maxLength={500}
          />
          <p className="text-xs text-gray-400 mt-2 text-right">{description.length}/500</p>
        </div>

        <div>
          <label className="block mb-3 text-sm text-gray-600">募集人数（ホスト含む）</label>
          <div className="flex items-center gap-3">
            <Users size={20} className="text-gray-400" />
            <input
              type="number"
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(e.target.value)}
              min="2"
              max="50"
              className="flex-1 px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
            />
            <span className="text-gray-600">名</span>
          </div>
        </div>

        <div>
          <label className="block mb-3 text-sm text-gray-600">タグ（最大5個）</label>
          <div className="flex gap-2 mb-3">
            <input
              type="text"
              placeholder="例：オンライン"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') { e.preventDefault(); addTag(); }
              }}
              className="flex-1 px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
              maxLength={15}
            />
            <button
              onClick={addTag}
              disabled={tags.length >= 5 || !tagInput.trim()}
              className={`px-4 py-3 rounded-xl transition-colors ${
                tags.length < 5 && tagInput.trim()
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              }`}
            >
              追加
            </button>
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {tags.map((tag, i) => (
                <button
                  key={i}
                  onClick={() => setTags(tags.filter((_, j) => j !== i))}
                  className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-full text-sm flex items-center gap-1"
                >
                  #{tag}
                  <X size={14} />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="px-5 py-4 border-t border-gray-100 bg-gray-50">
        <p className="text-xs text-gray-500 leading-relaxed">
          ※ 投稿後すぐに募集一覧に反映されます
          <br />※ 個人を特定できる情報（住所・電話番号等）の記載はお控えください
        </p>
      </div>
    </div>
  );
}
