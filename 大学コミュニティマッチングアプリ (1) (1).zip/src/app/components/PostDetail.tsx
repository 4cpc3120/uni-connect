import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, Users, MessageCircle, Tag, CheckCircle } from 'lucide-react';
import {
  getPost,
  getCurrentUserId,
  joinPost,
  leavePost,
  formatTimeAgo,
  type Post,
} from '../lib/store';

const CATEGORY_COLORS: Record<string, string> = {
  '就活': 'bg-blue-100 text-blue-700',
  '勉強': 'bg-green-100 text-green-700',
  'サークル': 'bg-purple-100 text-purple-700',
  'その他': 'bg-orange-100 text-orange-700',
};

export default function PostDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<Post | null>(null);
  const [joined, setJoined] = useState(false);
  const userId = getCurrentUserId();

  useEffect(() => {
    if (id) {
      const p = getPost(id);
      setPost(p);
    }
  }, [id]);

  if (!post) {
    return (
      <div className="min-h-full bg-gray-50 flex items-center justify-center">
        <p className="text-gray-400">募集が見つかりません</p>
      </div>
    );
  }

  const isHost = post.hostId === userId;
  const isParticipant = post.participants.includes(userId);
  const isMember = isHost || isParticipant;
  const isFull = post.participants.length >= post.maxParticipants - 1;
  const isClosed = post.status === 'closed';
  const totalCount = post.participants.length + 1;

  const handleJoin = () => {
    const ok = joinPost(post.id);
    if (ok) {
      setPost(getPost(post.id));
      setJoined(true);
    }
  };

  const handleLeave = () => {
    leavePost(post.id);
    setPost(getPost(post.id));
    setJoined(false);
  };

  const openChat = () => navigate(`/chat/${post.id}`);

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm sticky top-0 z-10 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="p-1">
          <ChevronLeft size={24} className="text-gray-600" />
        </button>
        <h1 className="text-xl flex-1">募集詳細</h1>
      </header>

      <div className="px-5 py-4 space-y-4">
        {/* Main post card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-2 mb-3">
            <span className={`text-xs px-3 py-1 rounded-full font-medium ${CATEGORY_COLORS[post.category]}`}>
              {post.category}
            </span>
            {isClosed && (
              <span className="text-xs px-3 py-1 rounded-full bg-gray-100 text-gray-500">
                募集終了
              </span>
            )}
            <span className="text-xs text-gray-400 ml-auto">{formatTimeAgo(post.createdAt)}</span>
          </div>

          <h2 className="text-lg mb-3 leading-snug">{post.title}</h2>
          <p className="text-sm text-gray-600 leading-relaxed mb-4">{post.description}</p>

          {post.tags.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap mb-4">
              <Tag size={14} className="text-gray-400" />
              {post.tags.map((tag, i) => (
                <span key={i} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                  #{tag}
                </span>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
            <Users size={16} className="text-gray-400" />
            <span className="text-sm text-gray-600">
              {totalCount} / {post.maxParticipants} 名参加中
            </span>
            <div className="flex-1 bg-gray-100 rounded-full h-1.5 ml-2">
              <div
                className="bg-blue-500 h-1.5 rounded-full transition-all"
                style={{ width: `${Math.min((totalCount / post.maxParticipants) * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Host info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-400 mb-3 uppercase tracking-wide">ホスト</p>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-white flex items-center justify-center font-medium">
              {post.hostName.charAt(0)}
            </div>
            <div>
              <p className="font-medium text-gray-900">{post.hostName}</p>
              <p className="text-sm text-gray-500">
                {post.hostFaculty} {post.hostYear}
              </p>
            </div>
            {isHost && (
              <span className="ml-auto text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded-full">
                あなた
              </span>
            )}
          </div>
        </div>

        {/* Join success banner */}
        {(joined || (isParticipant && !isHost)) && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4 flex items-start gap-3">
            <CheckCircle size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-green-800">参加中です</p>
              <p className="text-xs text-green-600 mt-0.5">
                チャットでホストや他のメンバーと交流しましょう
              </p>
            </div>
          </div>
        )}

        {/* Action buttons */}
        <div className="space-y-3 pb-6">
          {isHost && (
            <button
              onClick={openChat}
              className="w-full py-4 bg-blue-600 text-white rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-sm"
            >
              <MessageCircle size={20} />
              グループチャットを開く
            </button>
          )}

          {!isHost && isParticipant && (
            <>
              <button
                onClick={openChat}
                className="w-full py-4 bg-blue-600 text-white rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-sm"
              >
                <MessageCircle size={20} />
                チャットを開く
              </button>
              <button
                onClick={handleLeave}
                className="w-full py-3 bg-gray-100 text-gray-600 rounded-xl text-sm active:scale-95 transition-transform"
              >
                参加を取り消す
              </button>
            </>
          )}

          {!isHost && !isParticipant && (
            <button
              onClick={handleJoin}
              disabled={isFull || isClosed}
              className={`w-full py-4 rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-sm ${
                isFull || isClosed
                  ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 text-white'
              }`}
            >
              <Users size={20} />
              {isClosed ? '募集終了' : isFull ? '満員です' : 'この募集に参加する'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
