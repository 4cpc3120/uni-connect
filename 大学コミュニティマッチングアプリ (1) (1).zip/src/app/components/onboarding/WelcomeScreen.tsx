import { Users, BookOpen, Briefcase, TrendingUp } from 'lucide-react';

interface WelcomeScreenProps {
  onNext: () => void;
}

export default function WelcomeScreen({ onNext }: WelcomeScreenProps) {
  const features = [
    {
      icon: Briefcase,
      title: '就活仲間を見つける',
      description: 'GD練習やES添削の仲間を募集',
    },
    {
      icon: BookOpen,
      title: '一緒に学ぶ',
      description: '勉強会やプロジェクトメンバー募集',
    },
    {
      icon: Users,
      title: 'サークル活動',
      description: '新規サークル立ち上げや交流',
    },
    {
      icon: TrendingUp,
      title: '挑戦する仲間',
      description: '学部・学年を超えたつながり',
    },
  ];

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-blue-50 to-white">
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        <div className="w-24 h-24 bg-blue-600 rounded-3xl flex items-center justify-center mb-8 shadow-lg">
          <Users size={48} className="text-white" />
        </div>

        <h1 className="text-3xl text-center mb-3">UniConnect</h1>
        <p className="text-lg text-gray-600 text-center mb-12">
          大学生活を一人で終わらせない
        </p>

        <div className="w-full space-y-6 mb-12">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="flex items-start gap-4">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm">
                  <Icon size={24} className="text-blue-600" />
                </div>
                <div className="flex-1 pt-1">
                  <h3 className="mb-1">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="p-6 pb-8">
        <button
          onClick={onNext}
          className="w-full py-4 bg-blue-600 text-white rounded-xl shadow-lg active:scale-95 transition-transform"
        >
          はじめる
        </button>
        <p className="text-xs text-center text-gray-500 mt-4">
          大学のメールアドレスが必要です
        </p>
      </div>
    </div>
  );
}
