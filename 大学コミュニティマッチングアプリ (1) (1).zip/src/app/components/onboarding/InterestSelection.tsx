import { useState } from 'react';
import { Hash, AlertCircle, Sparkles } from 'lucide-react';

interface InterestSelectionProps {
  onComplete: (interests: string[]) => void;
}

export default function InterestSelection({ onComplete }: InterestSelectionProps) {
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [error, setError] = useState('');

  const interests = [
    '就活',
    'GD',
    'インターン',
    '自己分析',
    'ES添削',
    'プログラミング',
    'Web開発',
    'データ分析',
    'AI・機械学習',
    'デザイン',
    '起業',
    'ビジネス',
    'マーケティング',
    '統計学',
    '経済学',
    '語学',
    '英語',
    'TOEIC',
    '資格取得',
    '簿記',
    'バドミントン',
    'テニス',
    'フットサル',
    'バスケ',
    '音楽',
    '読書',
    '映画',
    '旅行',
    'カメラ',
    'カフェ巡り',
  ];

  const handleToggleInterest = (interest: string) => {
    setError('');

    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter((i) => i !== interest));
    } else {
      if (selectedInterests.length >= 10) {
        setError('興味のあることは最大10個まで選択できます');
        return;
      }
      setSelectedInterests([...selectedInterests, interest]);
    }
  };

  const handleSubmit = () => {
    setError('');

    if (selectedInterests.length < 3) {
      setError('最低3つ以上選択してください');
      return;
    }

    onComplete(selectedInterests);
  };

  return (
    <div className="h-full flex flex-col bg-white overflow-y-auto">
      <div className="flex-1 px-6 py-12">
        <div className="mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
            <Sparkles size={32} className="text-white" />
          </div>
          <h1 className="text-2xl mb-3">興味のあることを選択</h1>
          <p className="text-gray-600 mb-2">
            あなたの興味に合った募集をおすすめします
          </p>
          <div className="flex items-center gap-2 text-sm">
            <Hash size={16} className="text-blue-600" />
            <span className="text-blue-600">
              {selectedInterests.length}個選択中（3〜10個）
            </span>
          </div>
        </div>

        {error && (
          <div className="flex items-start gap-2 p-3 bg-red-50 rounded-lg mb-6">
            <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <div className="flex flex-wrap gap-2.5">
          {interests.map((interest) => {
            const isSelected = selectedInterests.includes(interest);
            return (
              <button
                key={interest}
                onClick={() => handleToggleInterest(interest)}
                className={`px-4 py-2.5 rounded-full border-2 transition-all ${
                  isSelected
                    ? 'bg-blue-600 border-blue-600 text-white shadow-md scale-105'
                    : 'bg-white border-gray-200 text-gray-700 hover:border-blue-300'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <Hash size={14} />
                  {interest}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4">
          <p className="text-sm text-gray-700 leading-relaxed">
            💡 後からマイページで変更できます。気軽に選んでみましょう！
          </p>
        </div>
      </div>

      <div className="p-6 pb-8 border-t border-gray-100">
        <button
          onClick={handleSubmit}
          className="w-full py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl shadow-lg active:scale-95 transition-transform disabled:from-gray-300 disabled:to-gray-300 disabled:cursor-not-allowed"
          disabled={selectedInterests.length < 3}
        >
          完了して始める
        </button>
      </div>
    </div>
  );
}
