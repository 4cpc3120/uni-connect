import { useState } from 'react';
import { User, AlertCircle } from 'lucide-react';
import { FACULTIES } from '../../lib/store';

interface PersonalInfoProps {
  onComplete: (info: {
    lastName: string;
    firstName: string;
    faculty: string;
    department: string;
    year: string;
    studentId: string;
  }) => void;
}

const YEARS = ['1年', '2年', '3年', '4年', '修士1年', '修士2年', '博士課程'];

export default function PersonalInfo({ onComplete }: PersonalInfoProps) {
  const [form, setForm] = useState({
    lastName: '',
    firstName: '',
    faculty: '',
    department: '',
    year: '',
    studentId: '',
  });
  const [error, setError] = useState('');

  const set = (key: keyof typeof form, val: string) =>
    setForm((prev) => ({ ...prev, [key]: val }));

  const handleSubmit = () => {
    setError('');
    if (!form.lastName || !form.firstName) { setError('氏名を入力してください'); return; }
    if (!form.faculty) { setError('学部を選択してください'); return; }
    if (!form.year) { setError('学年を選択してください'); return; }
    if (!form.studentId) { setError('学籍番号を入力してください'); return; }
    onComplete(form);
  };

  const isReady =
    form.lastName && form.firstName && form.faculty && form.year && form.studentId;

  return (
    <div className="h-full flex flex-col bg-white overflow-y-auto">
      <div className="flex-1 px-6 py-12">
        <div className="mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
            <User size={32} className="text-blue-600" />
          </div>
          <h1 className="text-2xl mb-3">基本情報の入力</h1>
          <p className="text-gray-600">プロフィール情報を入力してください</p>
        </div>

        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm text-gray-600 mb-2">姓</label>
              <input
                type="text"
                placeholder="山田"
                value={form.lastName}
                onChange={(e) => set('lastName', e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-2">名</label>
              <input
                type="text"
                placeholder="太郎"
                value={form.firstName}
                onChange={(e) => set('firstName', e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-2">学部</label>
            <select
              value={form.faculty}
              onChange={(e) => set('faculty', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors appearance-none"
            >
              <option value="">選択してください</option>
              {FACULTIES.map((f) => (
                <option key={f} value={f}>{f}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-2">
              学科・専攻 <span className="text-gray-400 font-normal">（任意）</span>
            </label>
            <input
              type="text"
              placeholder="例：経営情報学科"
              value={form.department}
              onChange={(e) => set('department', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-2">学年</label>
            <select
              value={form.year}
              onChange={(e) => set('year', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors appearance-none"
            >
              <option value="">選択してください</option>
              {YEARS.map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm text-gray-600 mb-2">学籍番号</label>
            <input
              type="text"
              placeholder="例：20231234"
              value={form.studentId}
              onChange={(e) => set('studentId', e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-50 rounded-lg">
              <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          <div className="bg-blue-50 rounded-xl p-4">
            <p className="text-xs text-blue-900 leading-relaxed">
              ※ 入力された情報は本人確認のために使用されます
              <br />※ 学籍番号は他のユーザーには公開されません
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 pb-8 border-t border-gray-100">
        <button
          onClick={handleSubmit}
          disabled={!isReady}
          className="w-full py-4 bg-blue-600 text-white rounded-xl shadow-lg active:scale-95 transition-transform disabled:bg-gray-200 disabled:text-gray-400"
        >
          次へ
        </button>
      </div>
    </div>
  );
}
