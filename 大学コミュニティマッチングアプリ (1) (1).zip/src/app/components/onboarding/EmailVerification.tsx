import { useState } from 'react';
import { Mail, AlertCircle, CheckCircle } from 'lucide-react';

interface EmailVerificationProps {
  onVerified: (email: string) => void;
}

export default function EmailVerification({ onVerified }: EmailVerificationProps) {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [error, setError] = useState('');

  const validate = (e: string) => /^[a-zA-Z0-9._%+-]+@tokai\.ac\.jp$/.test(e);

  const handleEmailSubmit = () => {
    setError('');
    if (!email) { setError('メールアドレスを入力してください'); return; }
    if (!validate(email)) {
      setError('東海大学のメールアドレス（@tokai.ac.jp）を入力してください');
      return;
    }
    setStep('code');
  };

  const handleCodeVerify = () => {
    setError('');
    if (!code) { setError('認証コードを入力してください'); return; }
    if (code.length !== 6) { setError('6桁の認証コードを入力してください'); return; }
    onVerified(email);
  };

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex-1 px-6 py-12">
        <div className="mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
            <Mail size={32} className="text-blue-600" />
          </div>
          <h1 className="text-2xl mb-3">
            {step === 'email' ? '大学メール認証' : '認証コード入力'}
          </h1>
          <p className="text-gray-600">
            {step === 'email'
              ? '東海大学のメールアドレス（@tokai.ac.jp）を入力してください'
              : `${email} に認証コードを送信しました`}
          </p>
        </div>

        {step === 'email' ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-600 mb-2">メールアドレス</label>
              <input
                type="email"
                placeholder="example@tokai.ac.jp"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleEmailSubmit()}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 rounded-lg">
                <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <div className="bg-blue-50 rounded-xl p-4">
              <div className="flex items-start gap-2">
                <CheckCircle size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-900">
                  <p className="mb-1 font-medium">対応メールアドレス</p>
                  <p className="text-blue-700">xxxx@tokai.ac.jp</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-600 mb-2">認証コード（6桁）</label>
              <input
                type="text"
                inputMode="numeric"
                placeholder="000000"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                onKeyDown={(e) => e.key === 'Enter' && handleCodeVerify()}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors text-center text-2xl tracking-widest"
                maxLength={6}
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 rounded-lg">
                <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            <p className="text-xs text-gray-400 text-center">
              ※ デモ版のため、6桁の任意の数字で認証できます
            </p>

            <button
              onClick={() => { setStep('email'); setCode(''); setError(''); }}
              className="text-sm text-blue-600 underline"
            >
              メールアドレスを変更する
            </button>
          </div>
        )}
      </div>

      <div className="p-6 pb-8">
        <button
          onClick={step === 'email' ? handleEmailSubmit : handleCodeVerify}
          disabled={step === 'email' ? !email : !code}
          className="w-full py-4 bg-blue-600 text-white rounded-xl shadow-lg active:scale-95 transition-transform disabled:bg-gray-200 disabled:text-gray-400"
        >
          {step === 'email' ? '認証コードを送信' : '認証する'}
        </button>
      </div>
    </div>
  );
}
