import { useState } from 'react';
import { FileText, ChevronRight, CheckCircle } from 'lucide-react';

interface TermsAgreementProps {
  onAgree: () => void;
  onViewTerms: () => void;
}

export default function TermsAgreement({ onAgree, onViewTerms }: TermsAgreementProps) {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex-1 px-6 py-12 overflow-y-auto">
        <div className="mb-8">
          <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
            <FileText size={32} className="text-blue-600" />
          </div>
          <h1 className="text-2xl mb-3">利用規約への同意</h1>
          <p className="text-gray-600">
            UniConnectをご利用いただくにあたり、以下の規約をご確認ください。
          </p>
        </div>

        <div className="space-y-3 mb-8">
          <div className="bg-gray-50 rounded-2xl p-5 space-y-4 text-sm text-gray-600 leading-relaxed">
            <div>
              <p className="font-medium text-gray-900 mb-1">対象ユーザー</p>
              <p>東海大学在学生（@tokai.ac.jp メール保有者）のみご利用いただけます。</p>
            </div>
            <div>
              <p className="font-medium text-gray-900 mb-1">サービスの目的</p>
              <p>就活仲間・勉強仲間・サークルメンバーを見つけるためのコミュニティサービスです。恋愛・異性交際を目的とした利用は禁止されています。</p>
            </div>
            <div>
              <p className="font-medium text-gray-900 mb-1">禁止事項（抜粋）</p>
              <ul className="space-y-1 list-disc pl-4">
                <li>他ユーザーへの嫌がらせ・誹謗中傷</li>
                <li>虚偽情報の登録・投稿</li>
                <li>商業目的での勧誘・営業活動</li>
                <li>個人情報の無断収集・漏洩</li>
              </ul>
            </div>
          </div>

          <button
            onClick={onViewTerms}
            className="w-full flex items-center justify-between px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm text-blue-600"
          >
            <span>利用規約の全文を読む</span>
            <ChevronRight size={18} />
          </button>
        </div>

        <button
          onClick={() => setAgreed(!agreed)}
          className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all ${
            agreed
              ? 'border-blue-600 bg-blue-50'
              : 'border-gray-200 bg-white'
          }`}
        >
          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
            agreed ? 'border-blue-600 bg-blue-600' : 'border-gray-300'
          }`}>
            {agreed && <CheckCircle size={16} className="text-white" />}
          </div>
          <span className={`text-sm ${agreed ? 'text-blue-700 font-medium' : 'text-gray-600'}`}>
            利用規約に同意します
          </span>
        </button>
      </div>

      <div className="p-6 pb-8">
        <button
          onClick={onAgree}
          disabled={!agreed}
          className={`w-full py-4 rounded-xl shadow-lg active:scale-95 transition-all ${
            agreed
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          }`}
        >
          同意して続ける
        </button>
      </div>
    </div>
  );
}
