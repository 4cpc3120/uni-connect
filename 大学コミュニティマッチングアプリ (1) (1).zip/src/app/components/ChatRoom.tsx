import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ChevronLeft, Send, Users } from 'lucide-react';
import {
  getPost,
  getMessages,
  addMessage,
  getCurrentUserId,
  formatTimeAgo,
  type Post,
  type Message,
} from '../lib/store';

export default function ChatRoom() {
  const { postId } = useParams<{ postId: string }>();
  const navigate = useNavigate();
  const [post, setPost] = useState<Post | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  const userId = getCurrentUserId();

  const refresh = useCallback(() => {
    if (postId) {
      setMessages(getMessages(postId));
    }
  }, [postId]);

  useEffect(() => {
    if (postId) {
      const p = getPost(postId);
      setPost(p);
      setMessages(getMessages(postId));
    }
  }, [postId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Refresh messages when tab becomes visible (simulates receiving messages)
  useEffect(() => {
    const onVisible = () => { if (document.visibilityState === 'visible') refresh(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [refresh]);

  const handleSend = () => {
    if (!input.trim() || !postId) return;
    addMessage(postId, input.trim());
    setMessages(getMessages(postId));
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!post) {
    return (
      <div className="flex-1 flex items-center justify-center bg-white">
        <p className="text-gray-400">チャットが見つかりません</p>
      </div>
    );
  }

  const totalMembers = post.participants.length + 1;

  return (
    <div className="flex-1 flex flex-col bg-white min-h-0">
      <header className="bg-white px-4 py-3 border-b border-gray-100 flex items-center gap-3 flex-shrink-0 shadow-sm">
        <button onClick={() => navigate(-1)} className="p-1">
          <ChevronLeft size={24} className="text-gray-600" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-medium truncate">{post.title}</h1>
          <div className="flex items-center gap-1 text-xs text-gray-400 mt-0.5">
            <Users size={12} />
            <span>{totalMembers}名</span>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-gray-50">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
              <Users size={28} className="text-blue-400" />
            </div>
            <p className="text-sm text-gray-500 font-medium">チャットを始めましょう</p>
            <p className="text-xs text-gray-400 mt-1">
              最初のメッセージを送って挨拶してみてください
            </p>
          </div>
        )}

        {messages.map((msg) => {
          const isMe = msg.senderId === userId;
          return (
            <div
              key={msg.id}
              className={`flex items-end gap-2 ${isMe ? 'justify-end' : 'justify-start'}`}
            >
              {!isMe && (
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-sm font-medium flex-shrink-0 mb-1">
                  {msg.senderName.charAt(0)}
                </div>
              )}
              <div className={`max-w-[72%] flex flex-col gap-1 ${isMe ? 'items-end' : 'items-start'}`}>
                {!isMe && (
                  <p className="text-xs text-gray-500 ml-1">{msg.senderName}</p>
                )}
                <div
                  className={`px-4 py-2.5 rounded-2xl ${
                    isMe
                      ? 'bg-blue-600 text-white rounded-br-sm'
                      : 'bg-white text-gray-900 rounded-bl-sm shadow-sm border border-gray-100'
                  }`}
                >
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                </div>
                <p className="text-xs text-gray-400 mx-1">{formatTimeAgo(msg.createdAt)}</p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div className="flex-shrink-0 px-4 py-3 bg-white border-t border-gray-100 flex items-end gap-2">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="メッセージを入力..."
          className="flex-1 px-4 py-2.5 bg-gray-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm resize-none max-h-28"
          rows={1}
        />
        <button
          onClick={handleSend}
          disabled={!input.trim()}
          className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 disabled:bg-gray-200 active:scale-95 transition-all"
        >
          <Send size={17} className={input.trim() ? 'text-white' : 'text-gray-400'} />
        </button>
      </div>
    </div>
  );
}
