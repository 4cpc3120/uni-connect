import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ChevronLeft, Users, MoreVertical, Trash2, MessageCircle, ToggleLeft, ToggleRight } from 'lucide-react';
import {
  getPosts,
  getCurrentUserId,
  deletePost,
  togglePostStatus,
  formatTimeAgo,
  type Post,
} from '../lib/store';

const CATEGORY_COLORS: Record<string, string> = {
  '就活': 'bg-blue-100 text-blue-600',
  '勉強': 'bg-green-100 text-green-600',
  'サークル': 'bg-purple-100 text-purple-600',
  'その他': 'bg-orange-100 text-orange-600',
};

export default function MyPosts() {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);
  const [showMenu, setShowMenu] = useState<string | null>(null);

  const reload = () => {
    const userId = getCurrentUserId();
    setPosts(getPosts().filter((p) => p.hostId === userId));
  };

  useEffect(() => {
    reload();
  }, []);

  const handleDelete = (postId: string) => {
    if (!confirm('この募集を削除しますか？')) return;
    deletePost(postId);
    setShowMenu(null);
    reload();
  };

  const handleToggleStatus = (postId: string) => {
    togglePostStatus(postId);
    setShowMenu(null);
    reload();
  };

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm sticky top-0 z-10">
        <div className="flex items-center gap-3 mb-1">
          <button onClick={() => navigate(-1)}>
            <ChevronLeft size={24} className="text-gray-600" />
          </button>
          <h1 className="text-xl">自分の募集</h1>
        </div>
        <p className="text-sm text-gray-500 ml-9">{posts.length}件の募集を作成</p>
      </header>

      {posts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 px-5 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <Users size={32} className="text-gray-400" />
          </div>
          <h3 className="mb-2">まだ募集を作成していません</h3>
          <p className="text-sm text-gray-500 mb-6">
            新しい募集を作成して仲間を集めましょう
          </p>
          <button
            onClick={() => navigate('/create')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg"
          >
            募集を作成
          </button>
        </div>
      ) : (
        <div className="px-5 py-4 space-y-3">
          {posts.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-xl p-4 shadow-sm border border-gray-100"
              onClick={() => showMenu && setShowMenu(null)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <h3 className="leading-snug">{post.title}</h3>
                    <span
                      className={`text-xs px-2 py-1 rounded-full flex-shrink-0 ${
                        post.status === 'open'
                          ? 'bg-green-100 text-green-600'
                          : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {post.status === 'open' ? '募集中' : '募集終了'}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 mb-3 line-clamp-2">{post.description}</p>

                  {post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {post.tags.map((tag, i) => (
                        <span key={i} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className={`text-xs px-3 py-1 rounded-full ${CATEGORY_COLORS[post.category]}`}>
                      {post.category}
                    </span>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span className="flex items-center gap-1">
                        <Users size={13} />
                        {post.participants.length + 1}/{post.maxParticipants}名
                      </span>
                      <span>{formatTimeAgo(post.createdAt)}</span>
                    </div>
                  </div>
                </div>

                <div className="relative ml-2 flex-shrink-0">
                  <button
                    onClick={(e) => { e.stopPropagation(); setShowMenu(showMenu === post.id ? null : post.id); }}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    <MoreVertical size={20} className="text-gray-400" />
                  </button>
                  {showMenu === post.id && (
                    <div className="absolute right-0 top-10 bg-white border border-gray-200 rounded-xl shadow-lg py-1 w-44 z-10">
                      <button
                        onClick={(e) => { e.stopPropagation(); handleToggleStatus(post.id); }}
                        className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-50 flex items-center gap-2 text-gray-700"
                      >
                        {post.status === 'open'
                          ? <><ToggleLeft size={16} /> 募集を締め切る</>
                          : <><ToggleRight size={16} /> 募集を再開する</>
                        }
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(post.id); }}
                        className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-50 flex items-center gap-2 text-red-500"
                      >
                        <Trash2 size={16} />
                        削除する
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => navigate(`/posts/${post.id}`)}
                  className="py-2.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                >
                  参加者を見る
                </button>
                <button
                  onClick={() => navigate(`/chat/${post.id}`)}
                  className="py-2.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors flex items-center justify-center gap-1.5 text-sm"
                >
                  <MessageCircle size={15} />
                  チャット
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
