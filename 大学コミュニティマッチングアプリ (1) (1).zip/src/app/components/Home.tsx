import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Plus, TrendingUp, Users, BookOpen, Briefcase } from 'lucide-react';
import { getPosts, formatTimeAgo, type Post } from '../lib/store';

const CATEGORIES = [
  { name: '就活', icon: Briefcase, color: 'bg-blue-100 text-blue-600' },
  { name: '勉強', icon: BookOpen, color: 'bg-green-100 text-green-600' },
  { name: 'サークル', icon: Users, color: 'bg-purple-100 text-purple-600' },
  { name: 'その他', icon: TrendingUp, color: 'bg-orange-100 text-orange-600' },
] as const;

const CATEGORY_COLORS: Record<string, string> = {
  '就活': 'bg-blue-50 text-blue-600',
  '勉強': 'bg-green-50 text-green-600',
  'サークル': 'bg-purple-50 text-purple-600',
  'その他': 'bg-orange-50 text-orange-600',
};

export default function Home() {
  const navigate = useNavigate();
  const [recentPosts, setRecentPosts] = useState<Post[]>([]);
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  useEffect(() => {
    const all = getPosts();
    const filtered = activeFilter
      ? all.filter((p) => p.category === activeFilter)
      : all;
    setRecentPosts(filtered.slice(0, 5));
  }, [activeFilter]);

  const handleCategoryClick = (name: string) => {
    setActiveFilter((prev) => (prev === name ? null : name));
  };

  return (
    <div className="min-h-full bg-gray-50">
      <header className="bg-white px-5 py-4 shadow-sm">
        <h1 className="text-xl text-blue-700 font-semibold">UniConnect</h1>
        <p className="text-sm text-gray-500 mt-0.5">大学生活を一人で終わらせない</p>
      </header>

      <div className="px-5 py-6">
        <div className="grid grid-cols-4 gap-3 mb-8">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isActive = activeFilter === cat.name;
            return (
              <button
                key={cat.name}
                onClick={() => handleCategoryClick(cat.name)}
                className="flex flex-col items-center gap-2"
              >
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${cat.color} ${
                    isActive ? 'ring-2 ring-offset-2 ring-blue-400 scale-95' : ''
                  }`}
                >
                  <Icon size={28} />
                </div>
                <span className={`text-xs ${isActive ? 'text-blue-600 font-medium' : 'text-gray-700'}`}>
                  {cat.name}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg">
            {activeFilter ? `${activeFilter}の募集` : '最近の募集'}
          </h2>
          <button
            onClick={() => navigate('/posts')}
            className="text-sm text-blue-600"
          >
            すべて見る
          </button>
        </div>

        {recentPosts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-400 text-sm">募集がまだありません</p>
            <button
              onClick={() => navigate('/create')}
              className="mt-3 px-5 py-2 bg-blue-600 text-white rounded-lg text-sm"
            >
              最初の募集を作成する
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {recentPosts.map((post) => (
              <button
                key={post.id}
                onClick={() => navigate(`/posts/${post.id}`)}
                className="w-full bg-white rounded-xl p-4 shadow-sm border border-gray-100 text-left active:scale-[0.99] transition-transform"
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="flex-1 pr-2 text-gray-900 leading-snug">{post.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full whitespace-nowrap ${CATEGORY_COLORS[post.category]}`}>
                    {post.category}
                  </span>
                </div>
                <p className="text-sm text-gray-500 line-clamp-1 mb-3">{post.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-medium">
                      {post.hostName.charAt(0)}
                    </div>
                    <span className="text-xs text-gray-500">
                      {post.hostFaculty} {post.hostYear}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-400">
                    <span>{post.participants.length + 1}/{post.maxParticipants}名</span>
                    <span>{formatTimeAgo(post.createdAt)}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={() => navigate('/create')}
        className="fixed right-5 bottom-20 w-14 h-14 bg-blue-600 rounded-full shadow-lg flex items-center justify-center text-white active:scale-95 transition-transform"
      >
        <Plus size={28} />
      </button>
    </div>
  );
}
