import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { X, Camera, Hash } from 'lucide-react';

export default function ProfileEdit() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    lastName: '',
    firstName: '',
    faculty: '',
    year: '',
    bio: '',
  });
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const faculties = [
    '国際学部', '経営学部', '観光学部', '情報通信学部', '政治経済学部',
    '法学部', '文学部', '文化社会学部', '教養学部', '児童教育学部',
    '体育学部', '健康学部', '理学部', '情報理工学部', '建築都市学部',
    '工学部', '医学部', '人文学部', '海洋学部', '分離融合学部',
    '農学部', '国際文化学部', '生物学部',
  ];

  const years = ['1年', '2年', '3年', '4年', '修士1年', '修士2年', '博士課程'];

  const interests = [
    '就活',
    'GD',
    'インターン',
    '自己分析',
    'ES添削',
    'プログラミング',
    'Web開発',
    'データ分析',
    'AI・機械学習',
    'デザイン',
    '起業',
    'ビジネス',
    'マーケティング',
    '統計学',
    '経済学',
    '語学',
    '英語',
    'TOEIC',
    '資格取得',
    '簿記',
    'バドミントン',
    'テニス',
    'フットサル',
    'バスケ',
    '音楽',
    '読書',
    '映画',
    '旅行',
    'カメラ',
    'カフェ巡り',
  ];

  useEffect(() => {
    const userInfo = localStorage.getItem('user_info');
    const userInterests = localStorage.getItem('user_interests');
    const userBio = localStorage.getItem('user_bio');

    if (userInfo) {
      const info = JSON.parse(userInfo);
      setFormData({
        lastName: info.lastName || '',
        firstName: info.firstName || '',
        faculty: info.faculty || '',
        year: info.year || '',
        bio: userBio || '',
      });
    }

    if (userInterests) {
      setSelectedInterests(JSON.parse(userInterests));
    }
  }, []);

  const handleToggleInterest = (interest: string) => {
    if (selectedInterests.includes(interest)) {
      setSelectedInterests(selectedInterests.filter((i) => i !== interest));
    } else {
      if (selectedInterests.length >= 10) {
        return;
      }
      setSelectedInterests([...selectedInterests, interest]);
    }
  };

  const handleSave = () => {
    const updatedInfo = {
      lastName: formData.lastName,
      firstName: formData.firstName,
      faculty: formData.faculty,
      year: formData.year,
      studentId: JSON.parse(localStorage.getItem('user_info') || '{}').studentId,
    };

    localStorage.setItem('user_info', JSON.stringify(updatedInfo));
    localStorage.setItem('user_interests', JSON.stringify(selectedInterests));
    localStorage.setItem('user_bio', formData.bio);

    navigate('/profile');
  };

  return (
    <div className="min-h-full bg-white overflow-y-auto pb-20">
      <header className="bg-white px-5 py-4 border-b border-gray-200 flex items-center justify-between sticky top-0 z-10">
        <button onClick={() => navigate(-1)}>
          <X size={24} className="text-gray-600" />
        </button>
        <h1 className="text-xl">プロフィール編集</h1>
        <button
          onClick={handleSave}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg"
        >
          保存
        </button>
      </header>

      <div className="px-5 py-6">
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white">
              <span className="text-3xl">{formData.lastName.charAt(0) || '山'}</span>
            </div>
            <button className="absolute bottom-0 right-0 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center border-2 border-gray-100">
              <Camera size={16} className="text-gray-600" />
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h3 className="mb-3 text-gray-700">基本情報</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm text-gray-600 mb-2">姓</label>
                  <input
                    type="text"
                    value={formData.lastName}
                    onChange={(e) =>
                      setFormData({ ...formData, lastName: e.target.value })
                    }
                    className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-600 mb-2">名</label>
                  <input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) =>
                      setFormData({ ...formData, firstName: e.target.value })
                    }
                    className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-2">学部</label>
                <select
                  value={formData.faculty}
                  onChange={(e) =>
                    setFormData({ ...formData, faculty: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors appearance-none"
                >
                  <option value="">選択してください</option>
                  {faculties.map((faculty) => (
                    <option key={faculty} value={faculty}>
                      {faculty}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-600 mb-2">学年</label>
                <select
                  value={formData.year}
                  onChange={(e) =>
                    setFormData({ ...formData, year: e.target.value })
                  }
                  className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors appearance-none"
                >
                  <option value="">選択してください</option>
                  {years.map((year) => (
                    <option key={year} value={year}>
                      {year}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block mb-2 text-gray-700">自己紹介</label>
            <textarea
              placeholder="あなたについて教えてください"
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:border-blue-500 focus:outline-none transition-colors resize-none"
              rows={4}
              maxLength={200}
            />
            <p className="text-xs text-gray-400 mt-2 text-right">
              {formData.bio.length}/200
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-gray-700">興味のあること</h3>
              <span className="text-sm text-blue-600">
                {selectedInterests.length}個選択中
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {interests.map((interest) => {
                const isSelected = selectedInterests.includes(interest);
                return (
                  <button
                    key={interest}
                    onClick={() => handleToggleInterest(interest)}
                    className={`px-3 py-2 rounded-full border-2 transition-all text-sm ${
                      isSelected
                        ? 'bg-blue-600 border-blue-600 text-white'
                        : 'bg-white border-gray-200 text-gray-700'
                    }`}
                  >
                    <span className="flex items-center gap-1">
                      <Hash size={12} />
                      {interest}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
