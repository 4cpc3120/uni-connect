import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router';
import Home from './components/Home';
import Posts from './components/Posts';
import PostDetail from './components/PostDetail';
import Chat from './components/Chat';
import ChatRoom from './components/ChatRoom';
import Profile from './components/Profile';
import CreatePost from './components/CreatePost';
import ProfileEdit from './components/ProfileEdit';
import ParticipatingPosts from './components/ParticipatingPosts';
import MyPosts from './components/MyPosts';
import BottomNav from './components/BottomNav';
import Onboarding from './components/Onboarding';
import TermsOfService from './components/TermsOfService';

const FULL_SCREEN_PATHS = ['/chat/'];

function Layout() {
  const location = useLocation();
  const isFullScreen = FULL_SCREEN_PATHS.some((p) => location.pathname.startsWith(p));

  return (
    <div className="h-screen w-full max-w-md mx-auto bg-white flex flex-col">
      <div className={isFullScreen ? 'flex-1 flex flex-col min-h-0' : 'flex-1 overflow-y-auto pb-16'}>
        <Routes>
          <Route path="/" element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<Home />} />
          <Route path="/posts" element={<Posts />} />
          <Route path="/posts/:id" element={<PostDetail />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/chat/:postId" element={<ChatRoom />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/profile/edit" element={<ProfileEdit />} />
          <Route path="/profile/participating" element={<ParticipatingPosts />} />
          <Route path="/profile/my-posts" element={<MyPosts />} />
          <Route path="/create" element={<CreatePost />} />
          <Route path="/terms" element={<TermsOfService />} />
        </Routes>
      </div>
      {!isFullScreen && <BottomNav />}
    </div>
  );
}

export default function App() {
  const [isOnboarded, setIsOnboarded] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const done = localStorage.getItem('onboarding_complete');
    setIsOnboarded(done === 'true');
    setIsLoading(false);
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem('onboarding_complete', 'true');
    setIsOnboarded(true);
  };

  if (isLoading) {
    return (
      <div className="h-screen w-full max-w-md mx-auto bg-white flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isOnboarded) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  );
}
