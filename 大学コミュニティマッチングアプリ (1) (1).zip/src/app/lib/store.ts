export type Category = '就活' | '勉強' | 'サークル' | 'その他';

export interface Post {
  id: string;
  title: string;
  description: string;
  category: Category;
  tags: string[];
  maxParticipants: number;
  participants: string[];
  hostId: string;
  hostName: string;
  hostFaculty: string;
  hostYear: string;
  createdAt: number;
  status: 'open' | 'closed';
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  createdAt: number;
}

export interface UserInfo {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  faculty: string;
  department: string;
  year: string;
  bio: string;
  interests: string[];
}

const K = {
  POSTS: 'uc_posts',
  USER_ID: 'uc_user_id',
  MSGS: (postId: string) => `uc_msgs_${postId}`,
  INITIALIZED: 'uc_initialized',
};

function genId(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

const SAMPLE_POSTS: Post[] = [
  {
    id: 'post_s1',
    title: '春休みGD練習会メンバー募集！',
    description: '外資系企業志望の3年生でGD練習をしたいです。週2〜3回、オンラインで実施予定です。ケース問題から始めて本番さながらの練習を行います。就活頑張りたい方、お気軽にご参加ください！',
    category: '就活',
    tags: ['GD', '外資系', 'オンライン'],
    maxParticipants: 6,
    participants: ['demo_u2', 'demo_u3'],
    hostId: 'demo_u1',
    hostName: '田中 健一',
    hostFaculty: '経営学部',
    hostYear: '3年',
    createdAt: Date.now() - 2 * 3600 * 1000,
    status: 'open',
  },
  {
    id: 'post_s2',
    title: '統計学・データサイエンス勉強会',
    description: 'データサイエンスに興味がある方と一緒に統計学を基礎から学びたいです。教材はKaggleや統計学の参考書を使用予定。週1回オンラインで実施します。Python未経験者でも歓迎！',
    category: '勉強',
    tags: ['統計学', 'データサイエンス', 'Python'],
    maxParticipants: 5,
    participants: ['demo_u1'],
    hostId: 'demo_u2',
    hostName: '鈴木 美咲',
    hostFaculty: '情報理工学部',
    hostYear: '2年',
    createdAt: Date.now() - 5 * 3600 * 1000,
    status: 'open',
  },
  {
    id: 'post_s3',
    title: 'バドミントンサークル立ち上げメンバー募集',
    description: '初心者から経験者まで、楽しく活動できるバドミントンサークルを作りたいです。週1〜2回、大学の体育館を使用予定。一緒に盛り上げてくれる仲間を求めています！',
    category: 'サークル',
    tags: ['バドミントン', '初心者歓迎', '体育館'],
    maxParticipants: 15,
    participants: ['demo_u1', 'demo_u3', 'demo_u4'],
    hostId: 'demo_u3',
    hostName: '佐藤 陸',
    hostFaculty: '体育学部',
    hostYear: '1年',
    createdAt: Date.now() - 24 * 3600 * 1000,
    status: 'open',
  },
  {
    id: 'post_s4',
    title: 'Web開発勉強会（React / Node.js）',
    description: 'ReactとNode.jsを使ったフルスタック開発を一緒に学びましょう。実際にポートフォリオ作品を作ることを目標にしています。週2回オンラインで実施、初心者〜中級者歓迎。',
    category: '勉強',
    tags: ['プログラミング', 'React', 'Web開発'],
    maxParticipants: 8,
    participants: ['demo_u2'],
    hostId: 'demo_u4',
    hostName: '山本 拓海',
    hostFaculty: '情報通信学部',
    hostYear: '3年',
    createdAt: Date.now() - 2 * 24 * 3600 * 1000,
    status: 'open',
  },
  {
    id: 'post_s5',
    title: 'ベンチャー企業インターン情報交換会',
    description: 'ベンチャー企業のインターン経験を共有・一緒に対策しませんか。ES添削、面接練習なども相互にやり合えれば良いと思っています。就活解禁前に仲間を作りましょう！',
    category: '就活',
    tags: ['インターン', 'ベンチャー', 'ES添削'],
    maxParticipants: 10,
    participants: ['demo_u1', 'demo_u3'],
    hostId: 'demo_u5',
    hostName: '伊藤 莉子',
    hostFaculty: '政治経済学部',
    hostYear: '3年',
    createdAt: Date.now() - 3 * 24 * 3600 * 1000,
    status: 'open',
  },
  {
    id: 'post_s6',
    title: '国際交流イベント企画メンバー募集',
    description: '留学生と日本人学生が交流できるイベントを企画したいと思っています。英語・日本語どちらも使う予定。国際学部以外の方も大歓迎です！一緒に楽しいイベントを作りましょう。',
    category: 'その他',
    tags: ['国際交流', '留学生', 'イベント企画'],
    maxParticipants: 12,
    participants: ['demo_u2', 'demo_u5'],
    hostId: 'demo_u6',
    hostName: '中村 あおい',
    hostFaculty: '国際学部',
    hostYear: '2年',
    createdAt: Date.now() - 4 * 24 * 3600 * 1000,
    status: 'open',
  },
];

export function getCurrentUserId(): string {
  let id = localStorage.getItem(K.USER_ID);
  if (!id) {
    id = 'user_' + genId();
    localStorage.setItem(K.USER_ID, id);
  }
  return id;
}

export function getCurrentUser(): UserInfo | null {
  const raw = localStorage.getItem('user_info');
  if (!raw) return null;
  const info = JSON.parse(raw);
  return {
    id: getCurrentUserId(),
    email: localStorage.getItem('user_email') || '',
    firstName: info.firstName || '',
    lastName: info.lastName || '',
    faculty: info.faculty || '',
    department: info.department || '',
    year: info.year || '',
    bio: localStorage.getItem('user_bio') || '',
    interests: JSON.parse(localStorage.getItem('user_interests') || '[]'),
  };
}

function initStore() {
  if (localStorage.getItem(K.INITIALIZED)) return;
  localStorage.setItem(K.POSTS, JSON.stringify(SAMPLE_POSTS));
  localStorage.setItem(K.INITIALIZED, '1');
}

export function getPosts(): Post[] {
  initStore();
  const raw = localStorage.getItem(K.POSTS);
  return raw ? JSON.parse(raw) : [];
}

export function getPost(id: string): Post | null {
  return getPosts().find((p) => p.id === id) || null;
}

export function createPost(data: {
  title: string;
  description: string;
  category: Category;
  tags: string[];
  maxParticipants: number;
}): Post {
  const user = getCurrentUser();
  const userId = getCurrentUserId();
  const post: Post = {
    id: 'post_' + genId(),
    ...data,
    participants: [],
    hostId: userId,
    hostName: user ? `${user.lastName} ${user.firstName}` : 'あなた',
    hostFaculty: user?.faculty || '',
    hostYear: user?.year || '',
    createdAt: Date.now(),
    status: 'open',
  };
  const posts = getPosts();
  posts.unshift(post);
  localStorage.setItem(K.POSTS, JSON.stringify(posts));
  return post;
}

export function updatePost(updated: Post): void {
  const posts = getPosts().map((p) => (p.id === updated.id ? updated : p));
  localStorage.setItem(K.POSTS, JSON.stringify(posts));
}

export function deletePost(postId: string): void {
  const posts = getPosts().filter((p) => p.id !== postId);
  localStorage.setItem(K.POSTS, JSON.stringify(posts));
}

export function joinPost(postId: string): boolean {
  const post = getPost(postId);
  const userId = getCurrentUserId();
  if (!post || post.hostId === userId || post.participants.includes(userId)) return false;
  if (post.participants.length >= post.maxParticipants || post.status === 'closed') return false;
  post.participants.push(userId);
  updatePost(post);
  return true;
}

export function leavePost(postId: string): void {
  const post = getPost(postId);
  const userId = getCurrentUserId();
  if (!post) return;
  post.participants = post.participants.filter((id) => id !== userId);
  updatePost(post);
}

export function togglePostStatus(postId: string): void {
  const post = getPost(postId);
  if (!post) return;
  post.status = post.status === 'open' ? 'closed' : 'open';
  updatePost(post);
}

export function getMessages(postId: string): Message[] {
  const raw = localStorage.getItem(K.MSGS(postId));
  return raw ? JSON.parse(raw) : [];
}

export function addMessage(postId: string, content: string): Message {
  const user = getCurrentUser();
  const userId = getCurrentUserId();
  const msg: Message = {
    id: genId(),
    senderId: userId,
    senderName: user ? `${user.lastName} ${user.firstName}` : 'あなた',
    content,
    createdAt: Date.now(),
  };
  const msgs = getMessages(postId);
  msgs.push(msg);
  localStorage.setItem(K.MSGS(postId), JSON.stringify(msgs));
  return msg;
}

export function formatTimeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (m < 1) return 'たった今';
  if (m < 60) return `${m}分前`;
  if (h < 24) return `${h}時間前`;
  if (d < 7) return `${d}日前`;
  return `${Math.floor(d / 7)}週間前`;
}

export const FACULTIES = [
  '国際学部', '経営学部', '観光学部', '情報通信学部', '政治経済学部',
  '法学部', '文学部', '文化社会学部', '教養学部', '児童教育学部',
  '体育学部', '健康学部', '理学部', '情報理工学部', '建築都市学部',
  '工学部', '医学部', '人文学部', '海洋学部', '分離融合学部',
  '農学部', '国際文化学部', '生物学部',
];
